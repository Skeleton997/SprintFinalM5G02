package interfaces;

import java.util.List;

import modelo.Cliente;
import modelo.Usuario;

public interface ICliente {
		List<Cliente> listarClientes();
	    void registrarCliente(Cliente cliente);
}
