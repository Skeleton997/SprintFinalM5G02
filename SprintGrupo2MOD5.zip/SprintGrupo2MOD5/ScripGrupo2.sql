CREATE DATABASE sprintgrupo2;

USE sprintgrupo2;

-- Tabla "Capacitaciones"
CREATE TABLE Capacitaciones (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre VARCHAR(100) NOT NULL,
  detalle TEXT
);


-- Tabla "Usuarios"
CREATE TABLE Usuarios (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre_usuario VARCHAR(100) NOT NULL,
  fecha_nacimiento VARCHAR(100) NOT NULL,
  run VARCHAR(100) NOT NULL,
  tipo ENUM('Cliente', 'Administrativo', 'Profesional') NOT NULL
);

-- Inserción de 10 usuarios en la tabla Usuarios
INSERT INTO Usuarios (nombre_usuario, fecha_nacimiento, run, tipo) VALUES
('Juan Perez', '15/04/1985', '12345678-9', 'Cliente'),
('Ana Gonzalez', '22/08/1990', '23456789-0', 'Cliente'),
('Pedro Martinez', '12/05/1982', '34567890-1', 'Cliente'),
('Maria Rodriguez', '30/10/1995', '45678901-2', 'Administrativo'),
('Carlos Fernandez', '07/12/1988', '56789012-3', 'Administrativo'),
('Lucia Romero', '18/07/1992', '67890123-4', 'Profesional'),
('Javier Sanchez', '20/02/1979', '78901234-5', 'Profesional'),
('Sofia Castro', '25/11/1986', '89012345-6', 'Cliente'),
('Diego Torres', '10/03/1994', '90123456-7', 'Administrativo'),
('Valentina Vargas', '02/09/1980', '01234567-8', 'Profesional');

-- Tabla "Cliente"
CREATE TABLE Cliente (
  id INT PRIMARY KEY AUTO_INCREMENT,
  nombre_cliente VARCHAR(100) NOT NULL,
  apellido_cliente VARCHAR(100) NOT NULL,
  telefono VARCHAR(100) NOT NULL,
  direccion VARCHAR(100) NOT NULL,
  edad VARCHAR(100) NOT NULL,
  FOREIGN KEY (id) REFERENCES Usuarios(id) ON DELETE CASCADE
);

-- Tabla "Administrativo"
CREATE TABLE Administrativo (
  id INT PRIMARY KEY AUTO_INCREMENT,
  area VARCHAR(100) NOT NULL,
  experiencia VARCHAR(100) NOT NULL,
  FOREIGN KEY (id) REFERENCES Usuarios(id) ON DELETE CASCADE
);

-- Tabla "Profesional"
CREATE TABLE Profesional (
  id INT PRIMARY KEY AUTO_INCREMENT,
  titulo VARCHAR(100) NOT NULL,
  fecha_ingreso VARCHAR(100) NOT NULL,
  FOREIGN KEY (id) REFERENCES Usuarios(id) ON DELETE CASCADE
);
