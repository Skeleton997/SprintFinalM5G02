package controlador;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import implementacion.UsuarioImpl;
import interfaces.IUsuario;
import modelo.Usuario;

@WebServlet("/formulariousr")
public class CrearUsuario extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public CrearUsuario() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getRequestDispatcher("/views/formulariousr.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
    	// Obtener los datos del formulario
        String nombre = request.getParameter("nombre");
        String fechaDeNacimiento = request.getParameter("fechaNacimiento");
        String run = request.getParameter("run");
        String tipo = request.getParameter("userType");

        // Crear objeto Usuario

        Usuario usuario = new Usuario();
        usuario.setNombre(nombre);
        usuario.setFechaDeNacimiento(fechaDeNacimiento);
        usuario.setRun(run);
        usuario.setTipo(tipo);

        // Registrar el usuario en la base de datos
        IUsuario dao = new UsuarioImpl();
        dao.registrarUsuario(usuario);

        
        // Redirigir basado en el tipo de usuario
        if ("Cliente".equalsIgnoreCase(tipo)) {
            // Si es cliente, redirigir al formulario para completar sus datos
            response.sendRedirect(request.getContextPath() + "/formulariocliente");
        } else if ("Administrativo".equalsIgnoreCase(tipo)) {
            response.sendRedirect(request.getContextPath() + "/formularioadmin");
        } else if ("Profesional".equalsIgnoreCase(tipo)) {
            response.sendRedirect(request.getContextPath() + "/formularioprofesional");
        } else {
            response.sendRedirect(request.getContextPath() + "/formulariousr.jsp");
        }
    }
}
