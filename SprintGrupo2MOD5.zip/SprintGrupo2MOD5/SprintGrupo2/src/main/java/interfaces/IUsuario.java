package interfaces;

import java.util.List;
import modelo.Usuario;

/**
 * Interfaz IUsuario
 * 
 * Define las operaciones básicas (CRUD) relacionadas con la entidad Usuario.
 */
public interface IUsuario {
    List<Usuario> listarUsuarios();   // Método para listar todos los usuarios
    void registrarUsuario(Usuario usuario);  // Método para registrar un nuevo usuario
	List<Usuario> listarUsuariosPorTipo(String tipo);
}
