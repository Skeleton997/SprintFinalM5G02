package implementacion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import conexion.Conexion;
import interfaces.IAdmin;
import modelo.Administrativo;

public class AdminImpl implements IAdmin{
	@Override
    public List<Administrativo> listarAdministradores() {
        List<Administrativo> administradores = new ArrayList<>();
        Connection conn = null;
        String sql = "SELECT * FROM administrativo";
        
        try {
            conn = Conexion.getConnection();
            try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                	Administrativo administrativo = new Administrativo();
                	
                	administrativo.setArea(rs.getString("area"));
                	administrativo.setExperienciaPrevia(rs.getString("experiencia"));
                    administradores.add(administrativo);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        }
        return administradores;
	}
	
	 @Override
	    public void registrarAdministrativo(Administrativo administrativo) {
	        Connection conn = null;
	        String sql = "INSERT INTO administrativo (area, experiencia) VALUES (?, ?)";
	        
	        try {
	            conn = Conexion.getConnection();
	            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
	                pstmt.setString(1, administrativo.getArea());
	                pstmt.setString(2, administrativo.getExperienciaPrevia());
	                pstmt.executeUpdate();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	        
	        }
	        
	 	}
}
