package controlador;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import conexion.Conexion;
import implementacion.ClienteImpl;
import implementacion.ProfesionalImpl;
import interfaces.ICliente;
import interfaces.IProfesional;
import modelo.Cliente;
import modelo.Profesional;

/**
 * Servlet implementation class CrearProfesional
 */
@WebServlet("/formularioprofesional")
public class CrearProfesional extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CrearProfesional() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		getServletContext().getRequestDispatcher("/views/formularioprofesional.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		// Obtener los datos del profesional
        String titulo = request.getParameter("titulo");
        String fechaIngreso = request.getParameter("fechaIngreso");
        
     // Crear objeto Profesional
        Profesional profesional = new Profesional();
        
        profesional.setTitulo(titulo);
        profesional.setFechaIngreso(fechaIngreso);
        
        // Registrar el cliente en la base de datos
        IProfesional daoProfesional = new ProfesionalImpl();
        daoProfesional.registrarProfesional(profesional);

        // Redirigir a una página de éxito o de confirmación
        response.sendRedirect(request.getContextPath() + "/views/formulariousr.jsp");
	}

}
