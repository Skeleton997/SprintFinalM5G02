package interfaces;

import java.util.List;

import modelo.Administrativo;

public interface IAdmin {
	List<Administrativo> listarAdministradores();
    void registrarAdministrativo(Administrativo administrativo);
}
