package controlador;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import implementacion.ClienteImpl;
import interfaces.ICliente;
import modelo.Cliente;

@WebServlet("/formulariocliente")
public class CrearCliente extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public CrearCliente() {
        super();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        getServletContext().getRequestDispatcher("/views/formulariocliente.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener los datos del cliente
    	
        String nombreCliente = request.getParameter("nombreCliente");
        String apellidoCliente = request.getParameter("apellidoCliente");
        String telefono = request.getParameter("telefono");
        String direccion = request.getParameter("direccion");
        String edad = request.getParameter("edad");
        
        // Crear objeto Cliente
        Cliente cliente = new Cliente();
        
        cliente.setNombreCliente(nombreCliente);
        cliente.setApellidoCliente(apellidoCliente);
        cliente.setTelefono(telefono);
        cliente.setDireccion(direccion);
        cliente.setEdad(edad);

        // Registrar el cliente en la base de datos
        ICliente daoCliente = new ClienteImpl();
        daoCliente.registrarCliente(cliente);

        // Redirigir a una página de éxito o de confirmación
        response.sendRedirect(request.getContextPath() + "/views/formulariousr.jsp");
    }
}
